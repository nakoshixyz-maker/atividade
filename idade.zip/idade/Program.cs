﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Ano de nascimento: ");
        int ano = int.Parse(Console.ReadLine());

        int idade = DateTime.Now.Year - ano;

        if (idade >= 18)
            Console.WriteLine("Pode tirar CNH.");
        else
            Console.WriteLine("Ainda não pode tirar CNH.");
    }
}
