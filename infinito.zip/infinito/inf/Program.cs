﻿
        double numero;
        double soma = 0;

        do
        {
            Console.Write("Digite um número (0 para parar): ");
            numero = Convert.ToDouble(Console.ReadLine());

            soma += numero;

        } while (numero != 0);

        Console.WriteLine($"Soma total: {soma}");
    
