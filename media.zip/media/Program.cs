﻿
 Console.Write("Digite o primeiro valor: ");
 double valor1 = Convert.ToDouble(Console.ReadLine());

Console.Write("Digite o segundo valor: ");
 double valor2 = Convert.ToDouble(Console.ReadLine());

        if (valor1 > valor2)
        {
 Console.WriteLine($"O maior valor é {valor1}");
        }
        else if (valor2 > valor1)
        {
Console.WriteLine($"O maior valor é {valor2}");
        }
        else
        {
  Console.WriteLine("Os dois valores são iguais.");
        }
